NEON TIC-TAC-TOE PRO — ONLINE SETUP

Included features:
- Vs Computer and same-device modes
- Online friend rooms using Supabase Realtime Broadcast/Presence
- Numeric room numbers from 50 to 100
- Settings > About the Game: Creator Aaron; Made in Kerala, India
- Rematch, room chat, themes, profile, local stats and other existing features

IMPORTANT: Online multiplayer is not active until you configure Supabase and publish this folder on an HTTPS website. The source code cannot connect to a backend that has not been configured.

1. Create or open a Supabase project at https://supabase.com/.
2. In Project Settings / API (the exact menu name may vary), copy the Project URL and the public anon/publishable client key.
3. Open the game online, select Online Friends, then use Create Room or Join with code. When prompted, enter the Project URL and public anon/publishable key. The game stores these on that device in localStorage.
4. Publish index.html on an HTTPS static host (for example GitHub Pages). Both players must open the same published website.
5. Player A taps Create Room. The game selects a number from 50 to 100. Player B enters that exact number and taps Join with code.

ROOM NUMBER LIMITATION:
There are only 51 possible room numbers (50 through 100). This is suitable for testing/friends, not secure private matchmaking. Numbers can collide, and anyone who knows or guesses an active number may attempt to join. The current prototype uses realtime channels rather than a server-side room registry, so it cannot guarantee that each number is unique or reserve rooms reliably. For robust public use, implement a server-side room registry with unique active rooms and authentication.

SECURITY:
Never enter or publish a Supabase service_role/secret key. Use only the public anon/publishable key in the browser. Do not share your database password.

The game uses ephemeral Realtime channels; game state is not stored permanently in a database. Host closing the page may end the match. The profile, stats and leaderboard remain local to each device unless separately implemented on a trusted backend.
